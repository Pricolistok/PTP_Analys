#!/bin/bash

to_source=$(dirname "$(readlink -f "$0")")
cd "$to_source" || exit

if ! ./build_coverage.sh; then
    echo "Can't build executable file for coverage testing"
    exit 2
fi

if ! [[ -f "app.exe" ]]; then
    echo "Exe file does not exist"
    exit 2
fi

"./build_coverage.sh"
"./func_tests/scripts/func_tests.sh"
gcov "main.gcda"
